import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import Sidebar from './Sidebar';
import './Products.css';
import bgImage from './assets/abc.avif';

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#0088FE'];

function Products() {
    // 💡 දත්ත ආරක්ෂිතව තබා ගැනීමට states වෙන් වෙන්ව සහ පැහැදිලිව සකස් කළා
    const [products, setProducts] = useState([]); // Table එක සඳහා සියලුම භාණ්ඩ ලැයිස්තුව
    const [lowStockData, setLowStockData] = useState([]); // Bar Chart එක සඳහා දත්ත
    const [supplierStats, setSupplierStats] = useState([]); // Pie Chart එක සඳහා දත්ත
    const [totalProducts, setTotalProducts] = useState(0); // Total Products කවුන්ට් එක

    const [searchTerm, setSearchTerm] = useState(""); 
    const [isAddProductOpen, setIsAddProductOpen] = useState(false);
    const [isUpdateProductOpen, setIsUpdateProductOpen] = useState(false);
    
    const [nextId, setNextId] = useState("");
    const [suppliers, setSuppliers] = useState([]);
    const [selectedId, setSelectedId] = useState("");
    const [formData, setFormData] = useState({
        Barcode: '', Name: '', Brand: '', PurchasePrice: '', SellPrice: '', Quantity: '', Supplier: ''
    });

    // 📥 අපි කලින් හදපු API ලින්ක්ස් හරහා දත්ත වෙන වෙනම ලස්සනට Fetch කිරීම
    const loadAllPageData = () => {
        // 1. සියලුම Products ලබා ගැනීම (Table එකට සහ Total Count එකට)
        fetch('http://localhost:5000/api/products')
            .then(res => res.json())
            .then(resProducts => {
                const list = Array.isArray(resProducts) ? resProducts : (resProducts.products || []);
                setProducts(list);
                setTotalProducts(list.length);
            })
            .catch(err => console.error("Error fetching products:", err));

        // 2. Low Stock Products ලබා ගැනීම (Bar Chart එකට)
        fetch('http://localhost:5000/api/low-stock')
            .then(res => res.json())
            .then(resLowStock => setLowStockData(Array.isArray(resLowStock) ? resLowStock : []))
            .catch(err => console.error("Error fetching low stock:", err));

        // 3. Supplier Stats ලබා ගැනීම (Pie Chart එකට)
        fetch('http://localhost:5000/api/supplier-stats')
            .then(res => res.json())
            .then(resStats => setSupplierStats(Array.isArray(resStats) ? resStats : []))
            .catch(err => console.error("Error fetching supplier stats:", err));
    };

    useEffect(() => {
        loadAllPageData();
    }, []);

    // 🔍 Search Logic (Name, Brand, Barcode) - 'products' state එක කෙලින්ම භාවිතා කරයි
    const filteredProducts = (products || []).filter(prod => 
        prod.Product_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prod.Product_ID?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prod.Barcode?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prod.Brand?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleOpenAddProduct = () => {
        setFormData({ Barcode: '', Name: '', Brand: '', PurchasePrice: '', SellPrice: '', Quantity: '', Supplier: '' });
        fetch('http://localhost:5000/api/next-product-id').then(res => res.json()).then(res => setNextId(res.nextId));
        fetch('http://localhost:5000/api/get-suppliers').then(res => res.json()).then(res => {
            setSuppliers(res);
            setIsAddProductOpen(true);
        });
    };

    const handleEditClick = (product) => {
        setSelectedId(product.Product_ID);
        setFormData({
            Barcode: product.Barcode, Name: product.Product_name, Brand: product.Brand,
            PurchasePrice: product.Purchase_Price, SellPrice: product.Sell_Price,
            Quantity: product.Quantity, Supplier: product.SupplierID
        });
        fetch('http://localhost:5000/api/get-suppliers').then(res => res.json()).then(res => {
            setSuppliers(res);
            setIsUpdateProductOpen(true);
        });
    };

    const handleDelete = (id) => {
        if (window.confirm("Are you sure you want to delete this product?")) {
            fetch(`http://localhost:5000/api/delete-product/${id}`, { method: 'DELETE' })
                .then(() => loadAllPageData());
        }
    };

    const handleAddProduct = () => {
        if (parseFloat(formData.PurchasePrice) >= parseFloat(formData.SellPrice)) {
            alert("Error: Sell Price must be greater than Purchase Price!");
            return;
        }

        const payload = {
            Product_ID: nextId,
            Barcode: formData.Barcode,
            Product_name: formData.Name,
            Brand: formData.Brand,
            Purchase_Price: formData.PurchasePrice,
            Sell_Price: formData.SellPrice,
            Quantity: parseInt(formData.Quantity),
            SupplierID: formData.Supplier
        };

        fetch('http://localhost:5000/api/add-product', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }).then(() => { setIsAddProductOpen(false); loadAllPageData(); });
    };

    const handleUpdateProduct = () => {
        if (parseFloat(formData.PurchasePrice) >= parseFloat(formData.SellPrice)) {
            alert("Error: Sell Price must be greater than Purchase Price!");
            return;
        }

        const payload = {
            Product_name: formData.Name,
            Brand: formData.Brand,
            Purchase_Price: formData.PurchasePrice,
            Sell_Price: formData.SellPrice,
            Quantity: formData.Quantity,
            SupplierID: formData.Supplier,
            Barcode: formData.Barcode
        };

        fetch(`http://localhost:5000/api/update-product/${selectedId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }).then(() => { setIsUpdateProductOpen(false); loadAllPageData(); });
    };

    return (
        <div className="main-layout" style={{ backgroundImage: `url(${bgImage})` }}>
            <Sidebar />
            <div className="content-area">
                <div className="top-row">
                    <div className="header-info">
                        <span className="user-role">Manager</span>
                        <div className="user-icon"></div>
                    </div>
                </div>

                <div className="stats-container fadeInRight">
                    {/* 📊 Bar Chart සඳහා lowStockData යොදාගන්නා ලදී */}
                    <div className="glass-stat-card">
                        <h3>Low Stock Products</h3>
                        <ResponsiveContainer width="100%" height={150}>
                            <BarChart data={lowStockData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ddd" />
                                <XAxis dataKey="Product_name" tick={{fontSize: 10}} axisLine={false} tickLine={false} />
                                <YAxis tick={{fontSize: 10}} axisLine={false} tickLine={false} />
                                <Tooltip />
                                <Bar dataKey="Quantity" fill="#FF0000" radius={[5, 5, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>

                    {/* 🍩 Pie Chart සඳහා supplierStats යොදාගන්නා ලදී */}
                    <div className="glass-stat-card fadeInRight">
                        <h3>Suppliers</h3>
                        <ResponsiveContainer width="100%" height={150}>
                            <PieChart>
                                <Pie data={supplierStats} dataKey="count" nameKey="SupplierID" cx="50%" cy="50%" outerRadius={50}>
                                    {supplierStats.map((entry, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>

                    {/* 🔢 Total Products ගණන */}
                    <div className="glass-stat-card total-box fadeInRight">
                        <h3>Total Products</h3>
                        <h1 className="total-number">{totalProducts}</h1>
                    </div>
                </div>

                <div className="table-glass-container fadeInRight">
                    <div className="table-top-header">
                        <div className="title-section">
                            Products <span className="plus-icon" onClick={handleOpenAddProduct}>+</span>
                        </div>
                        <div className="search-container">
                            <input 
                                type="text" 
                                placeholder="Search Name, Brand, Barcode..." 
                                className="search-input"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                            <button className="search-btn-modern">
                                <svg viewBox="0 0 24 24" width="20" height="20" fill="white">
                                    <path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                    <table className="modern-table">
                        <thead>
                            <tr>
                                <th>BarCode</th><th>Product name</th><th>Quantity</th>
                                <th>Purchase Price</th><th>Sell Price</th><th>Supplier</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredProducts.map((p, index) => (
                                <tr key={index}>
                                    <td>{p.Barcode}</td><td>{p.Product_name}</td><td>{p.Quantity}</td>
                                    <td>Rs. {Number(p.Purchase_Price || 0).toFixed(2)}</td>
                                    <td>Rs. {Number(p.Sell_Price || 0).toFixed(2)}</td>
                                    <td>{p.SupplierID}</td>
                                    <td>
                                        <button className="edit-btn-small" onClick={() => handleEditClick(p)}>Edit</button>
                                        <button className="delete-btn-small" onClick={() => handleDelete(p.Product_ID)}>Delete</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {/* Sidebar Overlay (Add & Update) */}
                <div className={`add-product-overlay ${(isAddProductOpen || isUpdateProductOpen) ? 'open' : ''}`} onClick={() => { setIsAddProductOpen(false); setIsUpdateProductOpen(false); }}>
                    <div className="add-product-sidebar" onClick={(e) => e.stopPropagation()}>
                        <h2>{isUpdateProductOpen ? "Update Product" : "Add Product"}</h2>
                        
                        <div className="form-group">
                            <label>Product ID</label>
                            <input type="text" className="form-input" value={isUpdateProductOpen ? selectedId : nextId} readOnly />
                        </div>
                        <div className="form-group">
                            <label>Barcode</label>
                            <input type="text" name="Barcode" className="form-input" value={formData.Barcode} onChange={handleChange} placeholder="Enter barcode" />
                        </div>
                        <div className="form-group">
                            <label>Name</label>
                            <input type="text" name="Name" className="form-input" value={formData.Name} onChange={handleChange} placeholder="Enter name" />
                        </div>
                        <div className="form-group">
                            <label>Brand</label>
                            <input type="text" name="Brand" className="form-input" value={formData.Brand} onChange={handleChange} placeholder="Enter brand" />
                        </div>
                        <div className="form-group">
                            <label>Purchase Price</label>
                            <input type="text" name="PurchasePrice" className="form-input" value={formData.PurchasePrice} onChange={handleChange} placeholder="Enter purchase price" />
                        </div>
                        <div className="form-group">
                            <label>Sell Price</label>
                            <input type="text" name="SellPrice" className="form-input" value={formData.SellPrice} onChange={handleChange} placeholder="Enter sell price" />
                        </div>
                        <div className="form-group">
                            <label>Quantity</label>
                            <input type="number" name="Quantity" className="form-input" value={formData.Quantity} onChange={handleChange} placeholder="Enter quantity" />
                        </div>
                        <div className="form-group">
                            <label>Supplier</label>
                            <select name="Supplier" className="form-input" value={formData.Supplier} onChange={handleChange}>
                                <option value="">Select supplier</option>
                                {suppliers.map((s, i) => <option key={i} value={s.SupplierID}>{s.SupplierID} - {s.Name}</option>)}
                            </select>
                        </div>

                        <div className="form-buttons">
                            <button className="add-btn" onClick={isUpdateProductOpen ? handleUpdateProduct : handleAddProduct}>
                                {isUpdateProductOpen ? "Update" : "Add"}
                            </button>
                            <button className="cancel-btn" onClick={() => { setIsAddProductOpen(false); setIsUpdateProductOpen(false); }}>Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Products;