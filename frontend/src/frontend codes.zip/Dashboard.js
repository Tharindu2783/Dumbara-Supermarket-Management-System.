import React, { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import './Dashboard.css';
import bgImage from './assets/abc.avif';

const Dashboard = () => {
    const [stats, setStats] = useState({
        totalSales: 0,
        totalProfit: 0,
        totalProducts: 0,
        totalSuppliers: 0,
        salesGraphData: []
    });

    const expensesGraphData = [
        { name: 'Mon', amount: 12000 },
        { name: 'Tue', amount: 19000 },
        { name: 'Wed', amount: 15000 },
        { name: 'Thu', amount: 25000 },
        { name: 'Fri', amount: 22000 },
        { name: 'Sat', amount: 30000 },
        { name: 'Sun', amount: 18000 },
    ];

    const fetchDashboardData = () => {
        fetch('http://localhost:5000/api/dashboard-stats')
            .then(res => {
                if (!res.ok) throw new Error("Network response was not ok");
                return res.json();
            })
            .then(data => {
                const formattedChartData = data.chartData ? data.chartData.map(item => ({
                    name: item.Date,
                    sales: Number(item.DailySales)
                })) : [];

                setStats({
                    totalSales: data.totalSales ?? 0,
                    totalProfit: data.totalProfit ?? 0,
                    totalProducts: data.totalProducts ?? 0,
                    totalSuppliers: data.totalSuppliers ?? 0,
                    salesGraphData: formattedChartData
                });
            })
            .catch(err => console.error("Error fetching dashboard stats:", err));
    };

    useEffect(() => {
        fetchDashboardData();
    }, []);

    return (
        <div className="db-main-layout" style={{ backgroundImage: `url(${bgImage})` }}>
            <Sidebar />
            <div className="db-content-area">
                
                {/* Header Profile Info Row */}
                <div className="db-top-row">
                    <div className="db-header-info">
                        <span className="db-user-role">Manager</span>
                        <div className="db-user-icon"></div>
                    </div>
                </div>
                
                {/* Summary Cards Row */}
                <div className="db-stats-container db-fadeInRight">
                    <div className="db-glass-stat-card">
                        <h3>Gross Sales</h3>
                        <h1 className="db-total-number db-sales-color">
                            Rs. {(stats.totalSales || 0).toFixed(2)}
                        </h1>
                    </div>
                    <div className="db-glass-stat-card">
                        <h3>Gross Profit</h3>
                        <h1 className="db-total-number db-profit-color">
                            Rs. {(stats.totalProfit || 0).toFixed(2)}
                        </h1>
                    </div>
                    <div className="db-glass-stat-card">
                        <h3>Total Products</h3>
                        <h1 className="db-total-number db-items-color">
                            {stats.totalProducts}
                        </h1>
                    </div>
                    <div className="db-glass-stat-card">
                        <h3>Total Suppliers</h3>
                        <h1 className="db-total-number db-suppliers-color">
                            {stats.totalSuppliers}
                        </h1>
                    </div>
                </div>

                {/* Main Charts Area */}
                <div className="db-table-glass-container db-fadeInRight" style={{ padding: '25px 30px' }}>
                    <div className="db-table-top-header">
                        <div className="db-title-section">Total Sales Analytics</div>
                    </div>
                    
                    <div className="db-graph-wrapper">
                        <ResponsiveContainer width="100%" height={250}>
                            <LineChart data={stats.salesGraphData} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#666' }} axisLine={false} tickLine={false} />
                                <YAxis tick={{ fontSize: 11, fill: '#666' }} axisLine={false} tickLine={false} />
                                <Tooltip cursor={{ stroke: '#2ecc71', strokeWidth: 1 }} />
                                <Line type="monotone" dataKey="sales" name="Sales (Rs)" stroke="#2ecc71" strokeWidth={3} dot={{ fill: '#2ecc71', r: 5 }} activeDot={{ r: 8 }} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Expenses Chart Area */}
                <div className="db-table-glass-container db-fadeInRight" style={{ marginTop: '-20px', marginBottom: '50px', padding: '25px 30px' }}>
                    <div className="db-table-top-header">
                        <div className="db-title-section" style={{ color: '#e53935' }}>Store Expenses (UI View)</div>
                    </div>
                    
                    <div className="db-graph-wrapper">
                        <ResponsiveContainer width="100%" height={220}>
                            <LineChart data={expensesGraphData} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#666' }} axisLine={false} tickLine={false} />
                                <YAxis tick={{ fontSize: 11, fill: '#666' }} axisLine={false} tickLine={false} />
                                <Tooltip cursor={{ stroke: '#e53935', strokeWidth: 1 }} />
                                <Line type="monotone" dataKey="amount" name="Expenses (Rs)" stroke="#e53935" strokeWidth={2.5} strokeDasharray="5 5" dot={{ fill: '#e53935', r: 4 }} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default Dashboard;