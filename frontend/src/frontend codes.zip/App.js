import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Sidebar from './Sidebar';
import Products from './Products';
import Suppliers from './Suppliers'; 
import Billing from './Billing';
import Login from './Login';
import Invoice from './Invoice';
import './App.css';
import Report from './Report';
import Dashboard from './Dashboard';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />

        <Route
          path="/*"
          element={
            <div className="app-layout">
              <Sidebar /> 
              <div className="main-content">
                <Routes>
                  <Route path="/products" element={<Products />} />
                  <Route path="/suppliers" element={<Suppliers />} />
                  <Route path="/billing" element={<Billing />} />
                  <Route path="/invoices" element={<Invoice />} />
                  <Route path="/reports" element={<Report />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  
                  
                </Routes>
              </div>
            </div>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;