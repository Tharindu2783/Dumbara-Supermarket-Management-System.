import React, { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import './Invoice.css';
import bgImage from './assets/abc.avif';


const handleDelete = (invoiceID) => {
    if (window.confirm(`Are you sure you want to delete invoice ${invoiceID}?`)) {
        fetch(`http://localhost:5000/api/delete-invoice/${invoiceID}`, {
            method: 'DELETE'
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert("Invoice and its PDF deleted successfully!");
                
                // ✅ පිටුව රීලෝඩ් කර දත්ත අලුත් කිරීම
                window.location.reload(); 
            } else {
                alert("Failed to delete invoice: " + data.message);
            }
        })
        .catch(err => console.error("Error:", err));
    }
};



const Invoice = () => {
    const [invoices, setInvoices] = useState([]);
    const [stats, setStats] = useState({
        totalInvoices: 0,
        todayInvoices: 0,
        graphData: []
    });
    const [searchTerm, setSearchTerm] = useState("");

    const fetchInvoiceData = () => {
        fetch('http://localhost:5000/api/get-invoices')
            .then(res => res.json())
            .then(data => {
                setInvoices(data);
                calculateStats(data);
            })
            .catch(err => console.error("Error fetching invoices:", err));
    };

    const calculateStats = (allInvoices) => {
        const total = allInvoices.length;
        const today = new Date();
        const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`; 
        const todayCount = allInvoices.filter(inv => inv.Date === todayStr).length;

        const last7Invoices = [...allInvoices].slice(0, 7).reverse(); 
        const chartData = last7Invoices.map(inv => ({
            name: inv.InvoiceID,
            total: Number(inv.Total)
        }));

        setStats({
            totalInvoices: total,
            todayInvoices: todayCount,
            graphData: chartData
        });
    };

    useEffect(() => {
        fetchInvoiceData();
    }, []);


const openInvoicePDF = (invoiceID) => {
    // Backend එකේ සේව් වෙලා තියෙන PDF එකේ සෘජු ලින්ක් එක (Url) සෑදීම
    const pdfUrl = `http://localhost:5000/invoice/${invoiceID}.pdf`;
    
    // එම ලින්ක් එක බ්‍රවුසරයේ අලුත් ටැබ් එකක විවෘත කිරීම
    window.open(pdfUrl, '_blank');
};
    const filteredInvoices = invoices.filter(inv =>
        inv.InvoiceID?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="main-layout" style={{ backgroundImage: `url(${bgImage})` }}>
            <Sidebar />
            <div className="content-area">
                <div className="top-row">
                    <div className="header-info">
                        <span className="user-role">Manager</span>
                        <div className="user-icon"></div>
                    </div>
                </div>
                
                {/* Summary Cards */}
                <div className="stats-container fadeInRight">
                    <div className="glass-stat-card">
                        <h3>Total Invoices</h3>
                        <h1 className="total-number">{stats.totalInvoices}</h1>
                    </div>
                    <div className="glass-stat-card">
                        <h3>Today Invoices</h3>
                        <h1 className="total-number invoice-count-color">{stats.todayInvoices}</h1>
                    </div>
                    <div className="glass-stat-card">
                        <h3>Last 7 Invoices Total</h3>
                        <ResponsiveContainer width="100%" height={150}>
                            <BarChart data={stats.graphData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ddd" />
                                <XAxis dataKey="name" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                                <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                                <Tooltip cursor={{ fill: 'transparent' }} />
                                <Bar dataKey="total" fill="#FF0000" radius={[5, 5, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Invoices Table */}
                <div className="table-glass-container fadeInRight">
                    <div className="table-top-header">
                        <div className="title-section">Invoices</div>
                        <div className="search-container">
                            <input 
                                type="text" 
                                placeholder="Search Invoice ID..." 
                                className="search-input"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                    </div>

                    <table className="modern-table">
    <thead>
        <tr>
            <th>Invoice ID</th>
            <th>Total Products</th>
            <th>Total</th>
            <th>Date</th>
            <th>Time</th>
            <th>Actions</th> {/* 💡 ක්‍රියාකාරී බොත්තම් සඳහා Column එක */}
        </tr>
    </thead>
    <tbody>
        {filteredInvoices.length === 0 ? (
            <tr>
                <td colSpan="6" className="no-data-cell">No invoices found</td>
            </tr>
        ) : (
            filteredInvoices.map((inv, index) => (
                <tr key={index}>
                    <td style={{ fontWeight: 'bold' }}>{inv.InvoiceID}</td>
                    <td>{inv.Product_Qty}</td>
                    <td>{Number(inv.Total).toFixed(2)}</td>
                    <td>{inv.Date}</td>
                    <td>{inv.Time}</td>
                    <td>
                        {/* 💡 බොත්තම් දෙක එක පෙළට ලස්සනට තියාගන්න flex container එකක් භාවිතා කර ඇත */}
                        <div style={{ display: 'flex', gap: '10px' }}>
                            {/* 🔓 Open PDF Button */}
                            <button 
                                className="open-pdf-btn" 
                                onClick={() => openInvoicePDF(inv.InvoiceID)}
                            >
                                Open
                            </button>

                            {/* ❌ Delete Invoice Button */}
                            <button 
                                className="delete-invoice-btn" 
                                onClick={() => handleDelete(inv.InvoiceID)}
                            >
                                Delete
                            </button>
                        </div>
                    </td>
                </tr>
            ))
        )}
    </tbody>
</table>
                </div>

            </div>
        </div>
    );
};

export default Invoice;