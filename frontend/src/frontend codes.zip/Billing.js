import React, { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import './Billing.css';
import bgImage from './assets/abc.avif';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable'; 

function Billing() {
    const [billItems, setBillItems] = useState([]);
    const [stats, setStats] = useState({ lastTransaction: 0, todayCount: 0 });
    
    const [barcode, setBarcode] = useState('');
    const [item, setItem] = useState('');
    const [qty, setQty] = useState(1);
    const [price, setPrice] = useState('');
    const [purchasePrice, setPurchasePrice] = useState(0); 

    const [inputCash, setInputCash] = useState('');
    const [displayedCash, setDisplayedCash] = useState(0);
    const [balance, setBalance] = useState(0);

    // Stats ලබාගැනීම
    const fetchStats = () => {
        fetch('http://localhost:5000/api/billing-stats')
            .then(res => res.json())
            .then(data => setStats(data))
            .catch(err => console.error("Error fetching stats:", err));
    };

    useEffect(() => {
        fetchStats();
    }, []);

    // Barcode එක අනුව Product විස්තර සෙවීම
    useEffect(() => {
        if (barcode.trim().length > 0) {
            const delayDebounceFn = setTimeout(() => {
                fetch(`http://localhost:5000/api/get-product-by-barcode/${barcode}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            setItem(data.item);
                            setPrice(data.price);
                            setPurchasePrice(data.purchasePrice || 0); 
                            setQty(1);
                        } else {
                            setItem('');
                            setPrice('');
                            setPurchasePrice(0);
                        }
                    })
                    .catch(err => console.error(err));
            }, 300);

            return () => clearTimeout(delayDebounceFn);
        }
    }, [barcode]);

    // Table එකට අයිතම එකතු කිරීම
    const handleAddItem = () => {
        if (!item || !price || qty <= 0) {
            alert("Please enter valid item details!");
            return;
        }

        const newItem = {
            item: item,
            qty: parseInt(qty) || 1,
            price: parseFloat(price) || 0,
            purchasePrice: parseFloat(purchasePrice) || 0, 
            total: (parseInt(qty) || 1) * (parseFloat(price) || 0)
        };

        setBillItems([...billItems, newItem]);
        setBarcode('');
        setItem('');
        setPrice('');
        setQty(1);
        setPurchasePrice(0);
    };

    const total = billItems.reduce((acc, curr) => acc + curr.total, 0);

  const generatePDF = async (invoiceData, items) => {
    const doc = new jsPDF();

    // --- PDF DESIGN START ---
    // Dumbara Supermarket Header
    doc.setFontSize(22);
    doc.setFont("helvetica", "bold");
    doc.text("Dumbara Supermarket", 105, 20, { align: "center" });
    doc.setFontSize(10);
    doc.text("****************************************************", 105, 25, { align: "center" });
    
    doc.setFontSize(16);
    doc.text("INVOICE", 105, 35, { align: "center" });

    // Store Details & Invoice Info
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text("Dumbara Supermarket", 15, 45);
    doc.text("NO 113, Madiwaka Rd, Ududumbara", 15, 50);
    doc.text("dumbarasupermarket@gmail.com | 0707395519", 15, 55);
    doc.text(`Date : ${invoiceData.Date}`, 15, 60);
    doc.text(`Time : ${invoiceData.Time}`, 15, 65);
    doc.text(`Invoice No : ${invoiceData.InvoiceID}`, 15, 75);

    // Table settings
    const tableColumn = ["Name", "Unit Price", "Qty", "Total"];
    const tableRows = items.map(item => [
        item.item,
        `Rs ${item.price.toFixed(2)}`,
        item.qty,
        `Rs ${item.total.toFixed(2)}`
    ]);

    autoTable(doc, {
        startY: 80,
        head: [tableColumn],
        body: tableRows,
        theme: 'grid',
        headStyles: { fillColor: [255, 255, 255], textColor: [0, 0, 0], lineWidth: 0.1 },
        styles: { textColor: [0, 0, 0], lineWidth: 0.1 }
    });

    // Summary
    const finalY = doc.lastAutoTable.finalY + 10;
    doc.text(`Total : Rs ${invoiceData.Total.toFixed(2)}`, 15, finalY);
    doc.text(`Cash : Rs ${invoiceData.Cash.toFixed(2)}`, 15, finalY + 7);
    doc.text(`Balance : Rs ${invoiceData.Balance.toFixed(2)}`, 15, finalY + 14);

    // Footer
    doc.setFont("helvetica", "italic");
    doc.text("Thank you for your purchase!", 105, finalY + 30, { align: "center" });
    doc.text("Please come again!", 105, finalY + 37, { align: "center" });
    // --- PDF DESIGN END ---

    const pdfDataUri = doc.output('datauristring');
    const pdfBase64 = pdfDataUri.split(',')[1]; 
    const fileName = `${invoiceData.InvoiceID}.pdf`;

    // 2. Backend එකට යැවීම
    try {
        const response = await fetch('http://localhost:5000/api/save-pdf', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ pdfData: pdfBase64, fileName: fileName })
        });

        const result = await response.json();
        if (result.success) {
            console.log("PDF successfully saved to project folder!");
        }
    } catch (error) {
        console.error("Error connecting to save-pdf API:", error);
    }

    // 3. බ්‍රවුසරයට බාගත කිරීම
    doc.save(fileName); 
};

    // Pay Button Logic
    const handlePay = () => {
        const cashAmount = parseFloat(inputCash);

        if (billItems.length === 0) {
            alert("Please add items to the list first!");
            return;
        }

        if (isNaN(cashAmount) || cashAmount <= 0) {
            alert("Please enter a valid cash amount!");
            return;
        }

        if (cashAmount < total) {
            alert("Not enough cash!");
            return;
        }

        const totalQty = billItems.reduce((acc, curr) => acc + (parseInt(curr.qty) || 0), 0);
        const totalProfit = billItems.reduce((acc, curr) => {
            const sell = parseFloat(curr.price) || 0;
            const purchase = parseFloat(curr.purchasePrice) || 0;
            const itemQty = parseInt(curr.qty) || 0;
            return acc + ((sell - purchase) * itemQty);
        }, 0);

        const today = new Date();
        const currentDate = today.toISOString().split('T')[0]; 
        const currentTime = today.toTimeString().split(' ')[0]; 

        fetch('http://localhost:5000/api/next-invoice-id')
            .then(res => {
                if (!res.ok) throw new Error("Failed to fetch Next Invoice ID");
                return res.json();
            })
            .then(idData => {
                const nextInvId = idData.nextInvoiceId || 'INV1';
                const invoicePayload = {
                    InvoiceID: nextInvId,
                    Product_Qty: totalQty,
                    Total: total,
                    Profit: totalProfit,
                    Date: currentDate,
                    Time: currentTime
                };

                return fetch('http://localhost:5000/api/add-invoice', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(invoicePayload)
                }).then(res => {
                    if (!res.ok) throw new Error("Failed to save Invoice");
                    return res.json();
                }).then(saveData => {
                    return { saveData, invoicePayload };
                });
            })
            .then(({ saveData, invoicePayload }) => {
                if (saveData.success) {
                    const invoiceDetails = {
                        InvoiceID: invoicePayload.InvoiceID,
                        Date: invoicePayload.Date,
                        Time: invoicePayload.Time,
                        Total: invoicePayload.Total,
                        Cash: cashAmount,
                        Balance: cashAmount - total
                    };

                    generatePDF(invoiceDetails, billItems);

                    alert("Payment Successful & Invoice Downloaded!");

                    setBillItems([]);
                    setInputCash('');
                    setDisplayedCash(0);
                    setBalance(0);
                    fetchStats();
                }
            })
            .catch(err => {
                console.error("Error processing payment:", err);
                alert("Payment Failed! Reason: " + err.message);
            });
    };

    return (
        <div className="billing-layout" style={{ backgroundImage: `url(${bgImage})` }}>
            <Sidebar />
            <div className="billing-content">
                <div className="billing-top-row">
                    <div className="header-info">
                        <span className="user-role">Manager</span>
                        <div className="user-icon"></div>
                    </div>
                </div>

                <div className="billing-stats-container">
    {/* 🏆 Last Transaction Card */}
    <div className="billing-glass-card">
        <h3 className="card-title">Last Transaction</h3>
        <div className="stat-number">
            {stats.lastTransaction ? Number(stats.lastTransaction).toFixed(2) : "0.00"}
        </div> 
    </div>

    {/* 🏆 Today Transactions Card */}
    <div className="billing-glass-card">
        <h3 className="card-title">Today Transactions</h3>
        <div className="stat-number">
            {stats.todayCount || 0}
        </div> 
    </div>
</div>

                <div className="billing-main-grid fadeInRight">
                    <div className="billing-form-section glass-effect">
                        <div className="bill-form-group">
                            <input type="text" placeholder="Bar Code" className="billing-input-field" value={barcode} onChange={(e) => setBarcode(e.target.value)} />
                        </div>
                        <div className="bill-form-group">
                            <input type="text" placeholder="Item" className="billing-input-field" value={item} onChange={(e) => setItem(e.target.value)} />
                        </div>
                        <div className="bill-form-group">
                            <input type="number" placeholder="Qty" className="billing-input-field" value={qty} onChange={(e) => setQty(e.target.value)} min="1" />
                        </div>
                        <div className="bill-form-group">
                            <input type="number" placeholder="Price" className="billing-input-field" value={price} onChange={(e) => setPrice(e.target.value)} />
                        </div>
                        
                        <button className="billing-add-item-btn" onClick={handleAddItem}>Add Item</button>

                        <div className="billing-payment-box">
                            <input type="number" placeholder="Cash" className="billing-input-field cash-highlight" value={inputCash} onChange={(e) => setInputCash(e.target.value)} />
                            <button className="billing-pay-btn" onClick={handlePay}>Pay</button>
                        </div>
                    </div>

                    <div className="billing-table-section glass-effect">
                        <h3 className="table-title">Item List</h3>
                        <div className="bill-table-wrapper">
                            <table className="billing-modern-table">
                                <thead>
                                    <tr>
                                        <th>Item</th>
                                        <th>Qty</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {billItems.length === 0 ? (
                                        <tr><td colSpan="5" style={{ textAlign: 'center', color: '#999' }}>No items added yet.</td></tr>
                                    ) : (
                                        billItems.map((bi, index) => (
                                            <tr key={index}>
                                                <td>{bi.item}</td>
                                                <td>{bi.qty}</td>
                                                <td>{bi.price.toFixed(2)}</td>
                                                <td>{bi.total.toFixed(2)}</td>
                                                <td><button className="delete-btn-small" onClick={() => setBillItems(billItems.filter((_, i) => i !== index))}>Remove</button></td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                        
                        <div className="billing-summary-panel">
                            <div className="summary-item">Total : <span className="summary-val">Rs. {total.toFixed(2)}</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Billing;